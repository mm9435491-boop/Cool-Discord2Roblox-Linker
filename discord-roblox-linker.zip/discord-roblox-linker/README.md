# Discord-Roblox Account Linking System

A complete solution for linking Discord and Roblox accounts with verification codes, automatic partner discounts, and purchase notifications.

---

## 📁 What's Inside

```
discord-roblox-linker/
├── web-app/              # Deploy this to Vercel/other hosting
│   ├── src/              # Next.js source code
│   ├── prisma/           # Database schema
│   ├── package.json      # Dependencies
│   └── ...config files
│
├── roblox-scripts/       # Put these in your Roblox game
│   ├── ServerScript.lua  # → ServerScriptService
│   └── ClientScript.lua  # → StarterGui (as LocalScript)
│
└── README.md             # This file
```

---

## 🚀 Quick Start

### Step 1: Deploy the Web App

**Option A: Vercel (Recommended - Free)**

1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click "Add New" → "Project"
3. Import your GitHub repository (or drag & drop the `web-app` folder)
4. Click "Deploy"
5. Copy your deployment URL (e.g., `https://your-app.vercel.app`)

**Option B: Other Hosting**

The web-app works on any Node.js hosting:
- Railway
- Render
- DigitalOcean
- Heroku

---

### Step 2: Create Roblox Developer Products

1. Go to [create.roblox.com](https://create.roblox.com)
2. Select your experience
3. Go to **Monetization** → **Passes & Products**
4. Create products for these prices:

| Name | Price (Robux) |
|------|---------------|
| package_25 | 25 |
| package_30 | 30 |
| package_40 | 40 |
| package_50 | 50 |
| package_60 | 60 |
| package_70 | 70 |
| package_72 | 72 |
| package_80 | 80 |
| package_90 | 90 |
| package_100 | 100 |
| package_120 | 120 |
| package_150 | 150 |
| package_200 | 200 |
| package_250 | 250 |

5. Copy each product ID

---

### Step 3: Configure ServerScript.lua

Open `roblox-scripts/ServerScript.lua` and update:

```lua
local CONFIG = {
    -- Your Vercel deployment URL
    API_BASE_URL = "https://your-app.vercel.app",
    
    -- Your Discord webhook URL
    DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/XXX/XXX",
    
    -- Your Discord server ID (optional, for role verification)
    DISCORD_GUILD_ID = "123456789012345678",
    
    -- Roblox group settings (optional)
    ROBLOX_GROUP_ID = 0,
    PARTNER_GROUP_RANK = 0,
}
```

Update the product IDs:

```lua
local PRODUCT_IDS = {
    ["package_25"] = 1234567890,  -- Replace with your actual IDs
    ["package_30"] = 1234567891,
    -- ... etc
}
```

---

### Step 4: Add Scripts to Roblox

1. Open your place in Roblox Studio
2. Go to **Game Settings** → **Security**
3. Enable **Allow HTTP Requests**
4. Enable **Enable Studio Access to API Services**
5. Add the scripts:

| File | Location |
|------|----------|
| ServerScript.lua | ServerScriptService |
| ClientScript.lua | StarterGui → ScreenGui → LocalScript |

---

### Step 5: Create Discord Webhook

1. Go to your Discord server
2. Edit a channel → Integrations → Webhooks
3. Create a new webhook named "Advertisement System"
4. Copy the webhook URL to your config

---

## 🔗 How It Works

### Linking Flow

```
1. Player clicks "Link Discord" in Roblox
           ↓
2. Game calls API → generates 6-char code (e.g., "ABC123")
           ↓
3. Player sees code in popup with verification URL
           ↓
4. Player visits URL, enters code + Discord username
           ↓
5. Accounts linked! ✓
```

### Purchase Flow

```
1. Player selects ad options in game
           ↓
2. Game checks for partner status via API
           ↓
3. Discount applied if partner (20% off)
           ↓
4. Player completes purchase
           ↓
5. Notification sent to Discord with linked account info
```

---

## 🎯 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/link/generate` | Generate verification code |
| POST | `/api/verify/code` | Verify code & link accounts |
| GET | `/api/status/check?robloxUserId=XXX` | Check if account is linked |
| POST | `/api/partner/manage` | Set partner status |

---

## 🔧 Admin Commands (Roblox Console)

```lua
-- Clear cache for user
_G.ClearVerificationCache("userId")

-- Check link status
_G.GetLinkStatus("userId")
```

---

## 💡 Features

- ✅ 6-character verification codes
- ✅ 10-minute code expiration
- ✅ One-time use codes
- ✅ Automatic partner discounts (20%)
- ✅ Discord webhook notifications
- ✅ Real-time validation
- ✅ Audit logging

---

## 🆘 Need Help?

- Join Discord: https://discord.gg/wRTJTybKvp
- Check the SETUP_GUIDE.md in roblox-scripts folder for detailed instructions

---

## 📜 License

Free to use for your Roblox games and Discord servers!
