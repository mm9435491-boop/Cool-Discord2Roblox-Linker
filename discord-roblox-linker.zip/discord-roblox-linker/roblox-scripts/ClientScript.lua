--[[
	Enhanced Advertisement Purchase GUI with Discord Linking
	=========================================================
	Place this as a LocalScript in StarterGui > ScreenGui
	
	FEATURES:
	- Full-screen advertisement purchase interface
	- Discord account linking with verification code
	- Real-time discount status display
	- Beautiful modern UI with animations
	
	REQUIRES:
	- ServerScript.lua in ServerScriptService
	- RemoteEvents/Functions created by server script
--]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")

-- ============================================
-- WAIT FOR PLAYER AND REMOTES
-- ============================================

local player = Players.LocalPlayer
if not player then
	Players:GetPropertyChangedSignal("LocalPlayer"):Wait()
	player = Players.LocalPlayer
end

local playerGui = player:WaitForChild("PlayerGui")

-- Wait for server remotes with timeout
local function waitForRemote(name, timeout)
	timeout = timeout or 10
	local startTime = tick()
	
	while not ReplicatedStorage:FindFirstChild(name) do
		if tick() - startTime > timeout then
			warn("Timeout waiting for remote: " .. name)
			return nil
		end
		wait(0.1)
	end
	
	return ReplicatedStorage:FindFirstChild(name)
end

-- Give server time to initialize
wait(1.5)

local purchaseEvent = waitForRemote("InitiatePurchase")
local generateCodeFunc = waitForRemote("GenerateVerificationCode")
local checkLinkFunc = waitForRemote("CheckDiscordLink")
local getDiscountFunc = waitForRemote("GetDiscountStatus")
local notifyEvent = waitForRemote("PurchaseNotification")

-- ============================================
-- CONFIGURATION
-- ============================================

local PRICES = {
	pingTypes = {
		["Giveaway Ping (role)"] = 40,
		["@here Ping"] = 25,
		["@Sponsor Ping"] = 40,
		["@everyone Ping"] = 60
	},
	durations = {
		["7 days"] = 0,
		["14 days"] = 10,
		["30 days"] = 30
	},
	adPostFee = 10
}

-- Current selections
local selections = {
	pingType = "Giveaway Ping (role)",
	duration = "7 days",
	prizeAmount = 50,
	discordLinked = false,
	discordUsername = "",
	hasDiscount = false,
	discountPercent = 0,
	discountType = "None"
}

-- ============================================
-- HELPER FUNCTIONS
-- ============================================

local function calculateTotal()
	local total = 0
	total = total + (PRICES.pingTypes[selections.pingType] or 40)
	total = total + (PRICES.durations[selections.duration] or 0)
	total = total + selections.prizeAmount
	total = total + PRICES.adPostFee
	
	local originalTotal = total
	
	if selections.discountPercent > 0 then
		total = total * (1 - selections.discountPercent / 100)
		total = math.floor(total + 0.5)
	end
	
	return total, originalTotal
end

local function createUICorner(parent, radius)
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, radius or 8)
	corner.Parent = parent
	return corner
end

local function createUIStroke(parent, color, thickness)
	local stroke = Instance.new("UIStroke")
	stroke.Color = color or Color3.fromRGB(60, 60, 80)
	stroke.Thickness = thickness or 1
	stroke.Parent = parent
	return stroke
end

local function createUIGradient(parent, color1, color2, rotation)
	local gradient = Instance.new("UIGradient")
	gradient.Color = ColorSequence.new{
		ColorSequenceKeypoint.new(0, color1),
		ColorSequenceKeypoint.new(1, color2)
	}
	gradient.Rotation = rotation or 45
	gradient.Parent = parent
	return gradient
end

-- ============================================
-- POPUP SYSTEM
-- ============================================

local function createOverlay(screenGui)
	local overlay = Instance.new("Frame")
	overlay.Name = "Overlay"
	overlay.Size = UDim2.new(1, 0, 1, 0)
	overlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	overlay.BackgroundTransparency = 0.5
	overlay.BorderSizePixel = 0
	overlay.ZIndex = 50
	overlay.Parent = screenGui
	
	-- Click to close (optional)
	overlay.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			-- Could close popup here
		end
	end)
	
	return overlay
end

-- Verification Code Popup
local function createVerificationPopup(screenGui, codeInfo)
	local overlay = createOverlay(screenGui)
	
	local popup = Instance.new("Frame")
	popup.Name = "VerificationPopup"
	popup.Size = UDim2.new(0, 550, 0, 400)
	popup.Position = UDim2.new(0.5, -275, 0.5, -200)
	popup.BackgroundColor3 = Color3.fromRGB(25, 27, 35)
	popup.BorderSizePixel = 0
	popup.ZIndex = 51
	popup.Parent = screenGui
	
	createUICorner(popup, 16)
	createUIStroke(popup, Color3.fromRGB(88, 101, 242), 2)
	
	-- Title
	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, 0, 0, 60)
	title.Position = UDim2.new(0, 0, 0, 0)
	title.BackgroundTransparency = 1
	title.Text = "🔗 Link Your Discord Account"
	title.TextColor3 = Color3.fromRGB(255, 255, 255)
	title.TextSize = 28
	title.Font = Enum.Font.GothamBold
	title.ZIndex = 52
	title.Parent = popup
	
	-- Code display box
	local codeBox = Instance.new("Frame")
	codeBox.Size = UDim2.new(0.8, 0, 0, 80)
	codeBox.Position = UDim2.new(0.1, 0, 0, 80)
	codeBox.BackgroundColor3 = Color3.fromRGB(35, 38, 48)
	codeBox.BorderSizePixel = 0
	codeBox.ZIndex = 52
	codeBox.Parent = popup
	createUICorner(codeBox, 12)
	
	-- Code text
	local codeText = Instance.new("TextLabel")
	codeText.Size = UDim2.new(1, 0, 1, 0)
	codeText.BackgroundTransparency = 1
	codeText.Text = codeInfo.code
	codeText.TextColor3 = Color3.fromRGB(88, 101, 242)
	codeText.TextSize = 48
	codeText.Font = Enum.Font.GothamBold
	codeText.ZIndex = 53
	codeText.Parent = codeBox
	
	-- Timer
	local timerLabel = Instance.new("TextLabel")
	timerLabel.Size = UDim2.new(0.8, 0, 0, 40)
	timerLabel.Position = UDim2.new(0.1, 0, 0, 175)
	timerLabel.BackgroundTransparency = 1
	timerLabel.Text = "Code expires in 10:00"
	timerLabel.TextColor3 = Color3.fromRGB(255, 193, 7)
	timerLabel.TextSize = 20
	timerLabel.Font = Enum.Font.Gotham
	timerLabel.ZIndex = 52
	timerLabel.Parent = popup
	
	-- Instructions
	local instructions = Instance.new("TextLabel")
	instructions.Size = UDim2.new(0.8, 0, 0, 60)
	instructions.Position = UDim2.new(0.1, 0, 0, 225)
	instructions.BackgroundTransparency = 1
	instructions.Text = "1. Go to the verification website\n2. Enter this code and your Discord username\n3. Your accounts will be linked instantly!"
	instructions.TextColor3 = Color3.fromRGB(180, 185, 195)
	instructions.TextSize = 16
	instructions.Font = Enum.Font.Gotham
	instructions.TextXAlignment = Enum.TextXAlignment.Left
	instructions.ZIndex = 52
	instructions.Parent = popup
	
	-- URL Display
	local urlBox = Instance.new("Frame")
	urlBox.Size = UDim2.new(0.8, 0, 0, 45)
	urlBox.Position = UDim2.new(0.1, 0, 0, 295)
	urlBox.BackgroundColor3 = Color3.fromRGB(40, 42, 52)
	urlBox.BorderSizePixel = 0
	urlBox.ZIndex = 52
	urlBox.Parent = popup
	createUICorner(urlBox, 8)
	
	local urlText = Instance.new("TextLabel")
	urlText.Size = UDim2.new(0.9, 0, 1, 0)
	urlText.Position = UDim2.new(0.05, 0, 0, 0)
	urlText.BackgroundTransparency = 1
	urlText.Text = codeInfo.verifyUrl
	urlText.TextColor3 = Color3.fromRGB(100, 200, 255)
	urlText.TextSize = 16
	urlText.Font = Enum.Font.Gotham
	urlText.TextXAlignment = Enum.TextXAlignment.Left
	urlText.TextTruncate = Enum.TextTruncate.AtEnd
	urlText.ZIndex = 53
	urlText.Parent = urlBox
	
	-- Close button
	local closeBtn = Instance.new("TextButton")
	closeBtn.Size = UDim2.new(0.8, 0, 0, 50)
	closeBtn.Position = UDim2.new(0.1, 0, 0, 340)
	closeBtn.BackgroundColor3 = Color3.fromRGB(88, 101, 242)
	closeBtn.BorderSizePixel = 0
	closeBtn.Text = "Close"
	closeBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
	closeBtn.TextSize = 20
	closeBtn.Font = Enum.Font.GothamBold
	closeBtn.ZIndex = 52
	closeBtn.Parent = popup
	createUICorner(closeBtn, 10)
	
	-- Timer countdown
	local expiresAt = tonumber(codeInfo.expiresAt) or (tick() + 600)
	if type(codeInfo.expiresAt) == "string" then
		-- Parse ISO date
		local year, month, day, hour, min, sec = codeInfo.expiresAt:match("(%d+)-(%d+)-(%d+)T(%d+):(%d+):(%d+)")
		if year then
			expiresAt = os.time({
				year = tonumber(year),
				month = tonumber(month),
				day = tonumber(day),
				hour = tonumber(hour),
				min = tonumber(min),
				sec = tonumber(sec)
			})
		end
	end
	
	local timerConnection
	timerConnection = RunService.Heartbeat:Connect(function()
		local remaining = math.max(0, expiresAt - os.time())
		local mins = math.floor(remaining / 60)
		local secs = remaining % 60
		timerLabel.Text = string.format("Code expires in %d:%02d", mins, secs)
		
		if remaining <= 0 then
			timerLabel.Text = "Code expired! Generate a new one."
			timerLabel.TextColor3 = Color3.fromRGB(255, 59, 48)
			timerConnection:Disconnect()
		end
	end)
	
	-- Close button click
	closeBtn.MouseButton1Click:Connect(function()
		if timerConnection then
			timerConnection:Disconnect()
		end
		popup:Destroy()
		overlay:Destroy()
	end)
	
	return popup
end

-- ============================================
-- MAIN UI CREATION
-- ============================================

local function createUI()
	local screenGui = Instance.new("ScreenGui")
	screenGui.Name = "AdvertisementPurchaseGUI"
	screenGui.ResetOnSpawn = false
	screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	screenGui.Parent = playerGui
	
	-- Main Frame (Full Screen)
	local mainFrame = Instance.new("Frame")
	mainFrame.Name = "MainFrame"
	mainFrame.Size = UDim2.new(1, 0, 1, 0)
	mainFrame.BackgroundColor3 = Color3.fromRGB(10, 10, 15)
	mainFrame.BorderSizePixel = 0
	mainFrame.Parent = screenGui
	
	-- Background Gradient
	createUIGradient(mainFrame, Color3.fromRGB(15, 15, 25), Color3.fromRGB(8, 8, 12), 45)
	
	-- =====================
	-- LEFT SECTION
	-- =====================
	
	local leftSection = Instance.new("Frame")
	leftSection.Name = "LeftSection"
	leftSection.Size = UDim2.new(0.48, 0, 1, 0)
	leftSection.Position = UDim2.new(0, 0, 0, 0)
	leftSection.BackgroundTransparency = 1
	leftSection.Parent = mainFrame
	
	-- Title
	local titleLabel = Instance.new("TextLabel")
	titleLabel.Size = UDim2.new(0.85, 0, 0.12, 0)
	titleLabel.Position = UDim2.new(0.08, 0, 0.08, 0)
	titleLabel.BackgroundTransparency = 1
	titleLabel.Text = "Purchase an\nadvertisement"
	titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	titleLabel.TextSize = 52
	titleLabel.Font = Enum.Font.GothamBold
	titleLabel.TextXAlignment = Enum.TextXAlignment.Left
	titleLabel.TextYAlignment = Enum.TextYAlignment.Top
	titleLabel.Parent = leftSection
	
	-- Description
	local descLabel = Instance.new("TextLabel")
	descLabel.Size = UDim2.new(0.85, 0, 0.25, 0)
	descLabel.Position = UDim2.new(0.08, 0, 0.23, 0)
	descLabel.BackgroundTransparency = 1
	descLabel.Text = "You can purchase a sponsorship or advert for the YourBritishTrainFan's Giveaway Hub Discord server through this game.\n\nhttps://discord.gg/wRTJTybKvp\n\nSelect what you want for your advertisement and the advertisement will appear in the server within 2 working days."
	descLabel.TextColor3 = Color3.fromRGB(200, 205, 220)
	descLabel.TextSize = 19
	descLabel.Font = Enum.Font.Gotham
	descLabel.TextXAlignment = Enum.TextXAlignment.Left
	descLabel.TextYAlignment = Enum.TextYAlignment.Top
	descLabel.TextWrapped = true
	descLabel.LineHeight = 1.3
	descLabel.Parent = leftSection
	
	-- Discount Badge
	local discountBadge = Instance.new("Frame")
	discountBadge.Name = "DiscountBadge"
	discountBadge.Size = UDim2.new(0.85, 0, 0.08, 0)
	discountBadge.Position = UDim2.new(0.08, 0, 0.51, 0)
	discountBadge.BackgroundColor3 = Color3.fromRGB(255, 193, 7)
	discountBadge.BorderSizePixel = 0
	discountBadge.Visible = false
	discountBadge.Parent = leftSection
	createUICorner(discountBadge, 10)
	
	local badgeText = Instance.new("TextLabel")
	badgeText.Size = UDim2.new(0.95, 0, 1, 0)
	badgeText.Position = UDim2.new(0.025, 0, 0, 0)
	badgeText.BackgroundTransparency = 1
	badgeText.Text = "🎉 Partner Discount: 20% OFF"
	badgeText.TextColor3 = Color3.fromRGB(0, 0, 0)
	badgeText.TextSize = 22
	badgeText.Font = Enum.Font.GothamBold
	badgeText.Parent = discountBadge
	
	-- Discord Link Section
	local discordLinkFrame = Instance.new("Frame")
	discordLinkFrame.Name = "DiscordLink"
	discordLinkFrame.Size = UDim2.new(0.85, 0, 0.13, 0)
	discordLinkFrame.Position = UDim2.new(0.08, 0, 0.62, 0)
	discordLinkFrame.BackgroundColor3 = Color3.fromRGB(88, 101, 242)
	discordLinkFrame.BorderSizePixel = 0
	discordLinkFrame.Parent = leftSection
	createUICorner(discordLinkFrame, 10)
	
	local discordTitle = Instance.new("TextLabel")
	discordTitle.Size = UDim2.new(0.9, 0, 0.35, 0)
	discordTitle.Position = UDim2.new(0.05, 0, 0.15, 0)
	discordTitle.BackgroundTransparency = 1
	discordTitle.Text = "🔗 Link Your Discord Account"
	discordTitle.TextColor3 = Color3.fromRGB(255, 255, 255)
	discordTitle.TextSize = 22
	discordTitle.Font = Enum.Font.GothamBold
	discordTitle.TextXAlignment = Enum.TextXAlignment.Left
	discordTitle.Parent = discordLinkFrame
	
	local discordDesc = Instance.new("TextLabel")
	discordDesc.Size = UDim2.new(0.9, 0, 0.35, 0)
	discordDesc.Position = UDim2.new(0.05, 0, 0.52, 0)
	discordDesc.BackgroundTransparency = 1
	discordDesc.Text = "Click to get your verification code"
	discordDesc.TextColor3 = Color3.fromRGB(230, 230, 240)
	discordDesc.TextSize = 16
	discordDesc.Font = Enum.Font.Gotham
	discordDesc.TextXAlignment = Enum.TextXAlignment.Left
	discordDesc.Parent = discordLinkFrame
	
	local discordButton = Instance.new("TextButton")
	discordButton.Size = UDim2.new(1, 0, 1, 0)
	discordButton.BackgroundTransparency = 1
	discordButton.Text = ""
	discordButton.Parent = discordLinkFrame
	
	-- Notice
	local noticeLabel = Instance.new("TextLabel")
	noticeLabel.Size = UDim2.new(0.85, 0, 0.12, 0)
	noticeLabel.Position = UDim2.new(0.08, 0, 0.83, 0)
	noticeLabel.BackgroundTransparency = 1
	noticeLabel.Text = "Don't see your advert after 2 working days?\nOpen a ticket in the Discord server and we'll sort it."
	noticeLabel.TextColor3 = Color3.fromRGB(160, 165, 180)
	noticeLabel.TextSize = 17
	noticeLabel.Font = Enum.Font.GothamItalic
	noticeLabel.TextXAlignment = Enum.TextXAlignment.Left
	noticeLabel.TextYAlignment = Enum.TextYAlignment.Top
	noticeLabel.TextWrapped = true
	noticeLabel.LineHeight = 1.3
	noticeLabel.Parent = leftSection
	
	-- =====================
	-- RIGHT SECTION
	-- =====================
	
	local rightSection = Instance.new("Frame")
	rightSection.Name = "RightSection"
	rightSection.Size = UDim2.new(0.48, 0, 1, 0)
	rightSection.Position = UDim2.new(0.52, 0, 0, 0)
	rightSection.BackgroundTransparency = 1
	rightSection.Parent = mainFrame
	
	-- Options Title
	local optionsTitle = Instance.new("TextLabel")
	optionsTitle.Size = UDim2.new(0.85, 0, 0.08, 0)
	optionsTitle.Position = UDim2.new(0.08, 0, 0.08, 0)
	optionsTitle.BackgroundTransparency = 1
	optionsTitle.Text = "Options"
	optionsTitle.TextColor3 = Color3.fromRGB(255, 255, 255)
	optionsTitle.TextSize = 46
	optionsTitle.Font = Enum.Font.GothamBold
	optionsTitle.TextXAlignment = Enum.TextXAlignment.Left
	optionsTitle.Parent = rightSection
	
	-- Options Container
	local optionsScroll = Instance.new("ScrollingFrame")
	optionsScroll.Size = UDim2.new(0.88, 0, 0.65, 0)
	optionsScroll.Position = UDim2.new(0.08, 0, 0.17, 0)
	optionsScroll.BackgroundTransparency = 1
	optionsScroll.BorderSizePixel = 0
	optionsScroll.ScrollBarThickness = 6
	optionsScroll.ScrollBarImageColor3 = Color3.fromRGB(80, 80, 100)
	optionsScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
	optionsScroll.Parent = rightSection
	
	local listLayout = Instance.new("UIListLayout")
	listLayout.SortOrder = Enum.SortOrder.LayoutOrder
	listLayout.Padding = UDim.new(0, 18)
	listLayout.Parent = optionsScroll
	
	-- Function to create option card
	local function createOptionCard(title, subtitle, layoutOrder, isEditable)
		local card = Instance.new("Frame")
		card.Size = UDim2.new(1, -10, 0, 90)
		card.BackgroundColor3 = Color3.fromRGB(25, 28, 38)
		card.BorderSizePixel = 0
		card.LayoutOrder = layoutOrder
		card.Parent = optionsScroll
		createUICorner(card, 12)
		
		local titleLabel = Instance.new("TextLabel")
		titleLabel.Name = "TitleLabel"
		titleLabel.Size = UDim2.new(0.85, 0, 0.42, 0)
		titleLabel.Position = UDim2.new(0.06, 0, 0.12, 0)
		titleLabel.BackgroundTransparency = 1
		titleLabel.Text = title
		titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		titleLabel.TextSize = 21
		titleLabel.Font = Enum.Font.GothamBold
		titleLabel.TextXAlignment = Enum.TextXAlignment.Left
		titleLabel.Parent = card
		
		local subtitleLabel = Instance.new("TextLabel")
		subtitleLabel.Name = "SubtitleLabel"
		subtitleLabel.Size = UDim2.new(0.85, 0, 0.35, 0)
		subtitleLabel.Position = UDim2.new(0.06, 0, 0.57, 0)
		subtitleLabel.BackgroundTransparency = 1
		subtitleLabel.Text = subtitle
		subtitleLabel.TextColor3 = Color3.fromRGB(160, 165, 180)
		subtitleLabel.TextSize = 17
		subtitleLabel.Font = Enum.Font.Gotham
		subtitleLabel.TextXAlignment = Enum.TextXAlignment.Left
		subtitleLabel.Parent = card
		
		if isEditable then
			local arrow = Instance.new("TextLabel")
			arrow.Size = UDim2.new(0.08, 0, 0.5, 0)
			arrow.Position = UDim2.new(0.88, 0, 0.25, 0)
			arrow.BackgroundTransparency = 1
			arrow.Text = "▼"
			arrow.TextColor3 = Color3.fromRGB(200, 205, 220)
			arrow.TextSize = 20
			arrow.Font = Enum.Font.GothamBold
			arrow.Parent = card
			
			local button = Instance.new("TextButton")
			button.Size = UDim2.new(1, 0, 1, 0)
			button.BackgroundTransparency = 1
			button.Text = ""
			button.Parent = card
			
			button.MouseEnter:Connect(function()
				TweenService:Create(card, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(35, 38, 50)}):Play()
			end)
			
			button.MouseLeave:Connect(function()
				TweenService:Create(card, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(25, 28, 38)}):Play()
			end)
			
			return card, titleLabel, subtitleLabel, button
		end
		
		return card, titleLabel, subtitleLabel
	end
	
	-- Create option cards
	local giveawayCard = createOptionCard(
		"Giveaway",
		"We currently only provide giveaway advertisements",
		1,
		false
	)
	
	local pingCard, pingTitle, pingSubtitle, pingButton = createOptionCard(
		"Giveaway Ping (role)",
		"Price: 40 Robux",
		2,
		true
	)
	
	local durationCard, durationTitle, durationSubtitle, durationButton = createOptionCard(
		"7 days",
		"Price: No additional cost",
		3,
		true
	)
	
	local prizeCard, prizeTitle, prizeSubtitle, prizeButton = createOptionCard(
		"50 robux",
		"Prize amount to give away",
		4,
		true
	)
	
	-- Total and Purchase Section
	local bottomFrame = Instance.new("Frame")
	bottomFrame.Size = UDim2.new(0.88, 0, 0.17, 0)
	bottomFrame.Position = UDim2.new(0.08, 0, 0.83, 0)
	bottomFrame.BackgroundTransparency = 1
	bottomFrame.Parent = rightSection
	
	-- Pricing breakdown
	local pricingFrame = Instance.new("Frame")
	pricingFrame.Size = UDim2.new(1, 0, 0.5, 0)
	pricingFrame.Position = UDim2.new(0, 0, 0, 0)
	pricingFrame.BackgroundTransparency = 1
	pricingFrame.Parent = bottomFrame
	
	local originalPriceLabel = Instance.new("TextLabel")
	originalPriceLabel.Name = "OriginalPrice"
	originalPriceLabel.Size = UDim2.new(0.5, 0, 0.4, 0)
	originalPriceLabel.Position = UDim2.new(0, 0, 0, 0)
	originalPriceLabel.BackgroundTransparency = 1
	originalPriceLabel.Text = ""
	originalPriceLabel.TextColor3 = Color3.fromRGB(180, 180, 190)
	originalPriceLabel.TextSize = 18
	originalPriceLabel.Font = Enum.Font.Gotham
	originalPriceLabel.TextXAlignment = Enum.TextXAlignment.Left
	originalPriceLabel.TextStrikethrough = true
	originalPriceLabel.Visible = false
	originalPriceLabel.Parent = pricingFrame
	
	local totalLabel = Instance.new("TextLabel")
	totalLabel.Name = "Total"
	totalLabel.Size = UDim2.new(0.5, 0, 0.7, 0)
	totalLabel.Position = UDim2.new(0, 0, 0.3, 0)
	totalLabel.BackgroundTransparency = 1
	totalLabel.Text = "Total: 100 robux"
	totalLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	totalLabel.TextSize = 32
	totalLabel.Font = Enum.Font.GothamBold
	totalLabel.TextXAlignment = Enum.TextXAlignment.Left
	totalLabel.Parent = pricingFrame
	
	local purchaseButton = Instance.new("TextButton")
	purchaseButton.Size = UDim2.new(0.48, 0, 1, 0)
	purchaseButton.Position = UDim2.new(0.52, 0, 0.1, 0)
	purchaseButton.BackgroundColor3 = Color3.fromRGB(67, 181, 129)
	purchaseButton.BorderSizePixel = 0
	purchaseButton.Text = "Purchase Now"
	purchaseButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	purchaseButton.TextSize = 22
	purchaseButton.Font = Enum.Font.GothamBold
	purchaseButton.Parent = bottomFrame
	createUICorner(purchaseButton, 10)
	
	-- Button hover effects
	purchaseButton.MouseEnter:Connect(function()
		TweenService:Create(purchaseButton, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(77, 201, 149)}):Play()
	end)
	
	purchaseButton.MouseLeave:Connect(function()
		TweenService:Create(purchaseButton, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(67, 181, 129)}):Play()
	end)
	
	-- =====================
	-- UPDATE FUNCTIONS
	-- =====================
	
	local function updateTotal()
		local total, originalTotal = calculateTotal()
		
		if selections.discountPercent > 0 then
			originalPriceLabel.Text = "Original: " .. originalTotal .. " robux"
			originalPriceLabel.Visible = true
			totalLabel.Position = UDim2.new(0, 0, 0.5, 0)
			totalLabel.Text = "Total: " .. total .. " robux"
		else
			originalPriceLabel.Visible = false
			totalLabel.Position = UDim2.new(0, 0, 0.3, 0)
			totalLabel.Text = "Total: " .. total .. " robux"
		end
	end
	
	-- =====================
	-- DISCORD LINK HANDLER
	-- =====================
	
	discordButton.MouseButton1Click:Connect(function()
		if selections.discordLinked then
			return
		end
		
		-- Generate verification code
		if generateCodeFunc then
			local success, result = pcall(function()
				return generateCodeFunc:InvokeServer()
			end)
			
			if success and result and result.success then
				createVerificationPopup(screenGui, result)
			else
				-- Show error
				local errorMsg = (result and result.error) or "Failed to generate code"
				discordTitle.Text = "❌ Error"
				discordDesc.Text = errorMsg
				discordLinkFrame.BackgroundColor3 = Color3.fromRGB(255, 59, 48)
				
				-- Reset after 3 seconds
				wait(3)
				discordTitle.Text = "🔗 Link Your Discord Account"
				discordDesc.Text = "Click to get your verification code"
				discordLinkFrame.BackgroundColor3 = Color3.fromRGB(88, 101, 242)
			end
		end
	end)
	
	-- =====================
	-- OPTION SELECTION HANDLERS
	-- =====================
	
	-- Ping type options
	local pingTypes = {"Giveaway Ping (role)", "@here Ping", "@Sponsor Ping", "@everyone Ping"}
	local pingIndex = 1
	
	pingButton.MouseButton1Click:Connect(function()
		pingIndex = pingIndex % #pingTypes + 1
		selections.pingType = pingTypes[pingIndex]
		pingTitle.Text = selections.pingType
		pingSubtitle.Text = "Price: " .. PRICES.pingTypes[selections.pingType] .. " Robux"
		updateTotal()
	end)
	
	-- Duration options
	local durations = {"7 days", "14 days", "30 days"}
	local durationIndex = 1
	
	durationButton.MouseButton1Click:Connect(function()
		durationIndex = durationIndex % #durations + 1
		selections.duration = durations[durationIndex]
		local durationCost = PRICES.durations[selections.duration]
		durationTitle.Text = selections.duration
		durationSubtitle.Text = durationCost > 0 and "Price: +" .. durationCost .. " Robux" or "Price: No additional cost"
		updateTotal()
	end)
	
	-- Prize amount options
	local prizes = {50, 100, 150, 200, 250, 500}
	local prizeIndex = 1
	
	prizeButton.MouseButton1Click:Connect(function()
		prizeIndex = prizeIndex % #prizes + 1
		selections.prizeAmount = prizes[prizeIndex]
		prizeTitle.Text = selections.prizeAmount .. " robux"
		prizeSubtitle.Text = "Prize amount to give away"
		updateTotal()
	end)
	
	-- =====================
	-- PURCHASE HANDLER
	-- =====================
	
	purchaseButton.MouseButton1Click:Connect(function()
		if not purchaseEvent then
			warn("Purchase event not found!")
			return
		end
		
		local durationDays = tonumber(string.match(selections.duration, "%d+"))
		
		purchaseEvent:FireServer({
			pingType = selections.pingType,
			duration = durationDays,
			prizeAmount = selections.prizeAmount,
			adDetails = ""
		})
	end)
	
	-- =====================
	-- NOTIFICATION HANDLER
	-- =====================
	
	if notifyEvent then
		notifyEvent.OnClientEvent:Connect(function(data)
			if data.type == "error" then
				-- Show error notification
				local errorFrame = Instance.new("Frame")
				errorFrame.Size = UDim2.new(0, 400, 0, 60)
				errorFrame.Position = UDim2.new(0.5, -200, 0, 20)
				errorFrame.BackgroundColor3 = Color3.fromRGB(255, 59, 48)
				errorFrame.BorderSizePixel = 0
				errorFrame.ZIndex = 100
				errorFrame.Parent = screenGui
				createUICorner(errorFrame, 10)
				
				local errorText = Instance.new("TextLabel")
				errorText.Size = UDim2.new(0.9, 0, 1, 0)
				errorText.Position = UDim2.new(0.05, 0, 0, 0)
				errorText.BackgroundTransparency = 1
				errorText.Text = data.message
				errorText.TextColor3 = Color3.fromRGB(255, 255, 255)
				errorText.TextSize = 18
				errorText.Font = Enum.Font.Gotham
				errorText.Parent = errorFrame
				
				wait(5)
				errorFrame:Destroy()
			end
		end)
	end
	
	-- =====================
	-- INITIALIZATION
	-- =====================
	
	-- Check discount status
	if getDiscountFunc then
		local success, discountStatus = pcall(function()
			return getDiscountFunc:InvokeServer()
		end)
		
		if success and discountStatus then
			selections.hasDiscount = discountStatus.isPartner or discountStatus.hasSmallServerDiscount
			selections.discountPercent = discountStatus.discountPercent
			selections.discountType = discountStatus.discountType
			
			if selections.hasDiscount and selections.discountPercent > 0 then
				discountBadge.Visible = true
				badgeText.Text = "🎉 " .. selections.discountType .. " Discount: " .. selections.discountPercent .. "% OFF"
				noticeLabel.Position = UDim2.new(0.08, 0, 0.78, 0)
			else
				discountBadge.Visible = false
			end
		else
			discountBadge.Visible = false
		end
	else
		warn("GetDiscountStatus remote not found - discounts disabled")
		discountBadge.Visible = false
	end
	
	-- Check Discord link status
	if checkLinkFunc then
		local success, linkStatus = pcall(function()
			return checkLinkFunc:InvokeServer()
		end)
		
		if success and linkStatus and linkStatus.linked then
			selections.discordLinked = true
			selections.discordUsername = linkStatus.discordUsername
			discordTitle.Text = "✅ Discord Linked: " .. linkStatus.discordUsername
			discordDesc.Text = "Your account is connected"
			discordLinkFrame.BackgroundColor3 = Color3.fromRGB(67, 181, 129)
		end
	end
	
	updateTotal()
	
	return screenGui
end

-- Initialize UI with error handling
local success, result = pcall(createUI)

if success then
	print("✅ Enhanced Advertisement GUI Loaded")
else
	warn("❌ Failed to load GUI:", result)
end
