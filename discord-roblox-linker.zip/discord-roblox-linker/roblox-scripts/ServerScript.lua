--[[
	Enhanced Advertisement Purchase Server Script with Discord Linking
	=====================================================================
	Place this in ServerScriptService
	
	FEATURES:
	- Generate verification codes for Discord linking
	- Check verification status from web API
	- Partner discounts (verified via Discord)
	- Send purchase notifications to Discord webhook
	- Full purchase flow with developer products
	
	SETUP REQUIRED:
	1. Set CONFIG.API_BASE_URL to your deployed Next.js app URL
	2. Set CONFIG.DISCORD_WEBHOOK_URL to your Discord webhook
	3. Create developer products in Roblox for each price point
	4. Update PRODUCT_IDS with your product IDs
--]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local MarketplaceService = game:GetService("MarketplaceService")
local DataStoreService = game:GetService("DataStoreService")

-- ============================================
-- CONFIGURATION - EDIT THESE VALUES
-- ============================================
local CONFIG = {
	-- Your deployed Next.js API URL (e.g., "https://your-app.vercel.app")
	API_BASE_URL = "https://your-app.vercel.app",
	
	-- Discord webhook for notifications
	DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/YOUR_WEBHOOK_HERE",
	
	-- Your Discord server ID (for partner role verification)
	DISCORD_GUILD_ID = "YOUR_DISCORD_SERVER_ID",
	
	-- Your Roblox group ID (0 if not using group-based verification)
	ROBLOX_GROUP_ID = 0,
	
	-- Partner role rank in Roblox group (0 if not using)
	PARTNER_GROUP_RANK = 0,
}

-- ============================================
-- PRICING CONFIGURATION
-- ============================================
local DISCOUNTS = {
	PARTNER = 0.20,        -- 20% off for partners
	SMALL_SERVER = 0.20,   -- 20% off for small servers
	STAFF = 1.0,           -- 100% off (free) for staff
}

local PRICES = {
	pingTypes = {
		["@here"] = 25,
		["Sponsor Ping"] = 40,
		["@everyone"] = 60,
		["Giveaway Ping"] = 40,
	},
	durations = {
		[7] = 0,
		[14] = 10,
		[30] = 30,
	},
	adPostFee = 10,
}

-- ============================================
-- PRODUCT IDs - UPDATE WITH YOUR ACTUAL IDs
-- ============================================
local PRODUCT_IDS = {
	["package_25"] = 000000001,
	["package_30"] = 000000002,
	["package_40"] = 000000003,
	["package_50"] = 000000004,
	["package_60"] = 000000005,
	["package_70"] = 000000006,
	["package_72"] = 000000007,  -- 90 * 0.8 = 72 (partner price)
	["package_80"] = 000000008,
	["package_90"] = 000000009,
	["package_100"] = 000000010,
	["package_120"] = 000000011,
	["package_150"] = 000000012,
	["package_200"] = 000000013,
	["package_250"] = 000000014,
	-- Add more as needed
}

-- ============================================
-- DATASTORES
-- ============================================
local PURCHASE_DATASTORE = DataStoreService:GetDataStore("AdvertisementPurchases")
local VERIFICATION_CACHE = DataStoreService:GetDataStore("VerificationCache")

-- ============================================
-- HELPER FUNCTIONS
-- ============================================

-- Generate HTTP URL with proper encoding
local function buildUrl(endpoint, params)
	local url = CONFIG.API_BASE_URL .. endpoint
	if params then
		local queryParts = {}
		for key, value in pairs(params) do
			table.insert(queryParts, HttpService:UrlEncode(key) .. "=" .. HttpService:UrlEncode(tostring(value)))
		end
		if #queryParts > 0 then
			url = url .. "?" .. table.concat(queryParts, "&")
		end
	end
	return url
end

-- Safe HTTP GET request
local function httpGet(url)
	local success, response = pcall(function()
		return HttpService:GetAsync(url, false)
	end)
	
	if success and response then
		local decodeSuccess, data = pcall(function()
			return HttpService:JSONDecode(response)
		end)
		if decodeSuccess then
			return data
		end
	end
	return nil
end

-- Safe HTTP POST request
local function httpPost(url, data)
	local success, response = pcall(function()
		return HttpService:PostAsync(
			url,
			HttpService:JSONEncode(data),
			Enum.HttpContentType.ApplicationJson,
			false
		)
	end)
	
	if success and response then
		local decodeSuccess, responseData = pcall(function()
			return HttpService:JSONDecode(response)
		end)
		if decodeSuccess then
			return responseData
		end
	end
	return nil
end

-- ============================================
-- DISCORD LINKING SYSTEM
-- ============================================

-- Generate a verification code for a player
local function generateVerificationCode(player)
	local url = buildUrl("/api/link/generate")
	
	local data = httpPost(url, {
		robloxUserId = tostring(player.UserId),
		robloxUsername = player.Name,
		discordUsername = nil  -- Player will provide this on web
	})
	
	if data and data.success then
		return data.code, data.expiresAt, data.expiresIn
	end
	
	return nil, nil, nil
end

-- Check if a player's Discord is linked
local function checkDiscordLink(player)
	-- First check cache
	local cacheKey = "Link_" .. player.UserId
	local success, cachedData = pcall(function()
		return VERIFICATION_CACHE:GetAsync(cacheKey)
	end)
	
	if success and cachedData then
		-- Cache is valid for 5 minutes
		if cachedData.cachedAt and (os.time() - cachedData.cachedAt) < 300 then
			return cachedData.linked, cachedData
		end
	end
	
	-- Check API
	local url = buildUrl("/api/status/check", { robloxUserId = tostring(player.UserId) })
	local data = httpGet(url)
	
	if data then
		local cacheEntry = {
			linked = data.linked or false,
			discordUsername = data.discordUsername,
			discordId = data.discordId,
			isPartner = data.isPartner,
			partnerType = data.partnerType,
			hasSmallServerDiscount = data.hasSmallServerDiscount,
			cachedAt = os.time()
		}
		
		-- Update cache
		pcall(function()
			VERIFICATION_CACHE:SetAsync(cacheKey, cacheEntry, 300)
		end)
		
		return data.linked, data
	end
	
	return false, nil
end

-- Check if player is a partner
local function isPartner(player)
	-- Check Discord-linked status
	local linked, data = checkDiscordLink(player)
	if linked and data and data.isPartner then
		return true, data.partnerType or "partner"
	end
	
	-- Check Roblox group (fallback)
	if CONFIG.ROBLOX_GROUP_ID > 0 then
		local success, rank = pcall(function()
			return player:GetRankInGroup(CONFIG.ROBLOX_GROUP_ID)
		end)
		
		if success and rank >= CONFIG.PARTNER_GROUP_RANK then
			return true, "group"
		end
	end
	
	return false, nil
end

-- Check if player has small server discount
local function hasSmallServerDiscount(player)
	local linked, data = checkDiscordLink(player)
	if linked and data and data.hasSmallServerDiscount then
		return true
	end
	return false
end

-- ============================================
-- DISCORD WEBHOOK NOTIFICATIONS
-- ============================================

local function sendToDiscord(playerData, purchaseData, discountInfo)
	local embed = {
		title = "🎉 New Advertisement Purchase",
		color = 3447003,
		fields = {
			{
				name = "Player Information",
				value = string.format(
					"**Name:** %s (@%s)\n**User ID:** %d\n**Profile:** https://www.roblox.com/users/%d/profile",
					playerData.displayName,
					playerData.username,
					playerData.userId,
					playerData.userId
				),
				inline = false
			},
			{
				name = "Advertisement Details",
				value = string.format(
					"**Ping Type:** %s\n**Duration:** %d days\n**Prize Amount:** %d Robux",
					purchaseData.pingType,
					purchaseData.duration,
					purchaseData.prizeAmount
				),
				inline = false
			},
			{
				name = "Pricing",
				value = string.format(
					"**Original Cost:** %d Robux\n**Discount Applied:** %s\n**Final Cost:** %d Robux",
					purchaseData.originalCost or purchaseData.totalCost,
					discountInfo.type,
					purchaseData.totalCost
				),
				inline = false
			},
		},
		timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
		footer = {
			text = "YourBritishTrainFan's Giveaway Hub"
		}
	}
	
	-- Add Discord info if linked
	if purchaseData.discordUsername then
		table.insert(embed.fields, {
			name = "Discord Account",
			value = "**Username:** " .. purchaseData.discordUsername .. " ✅",
			inline = false
		})
	else
		table.insert(embed.fields, {
			name = "Discord Account",
			value = "❌ Not linked",
			inline = false
		})
	end
	
	-- Add additional details if provided
	if purchaseData.adDetails and purchaseData.adDetails ~= "" then
		table.insert(embed.fields, {
			name = "Additional Details",
			value = string.sub(purchaseData.adDetails, 1, 1000),
			inline = false
		})
	end
	
	-- Add action items
	table.insert(embed.fields, {
		name = "📋 Next Steps",
		value = "• Verify payment received\n• Schedule giveaway\n• Post within 2 working days",
		inline = false
	})
	
	local discordData = {
		username = "Advertisement System",
		avatar_url = "https://cdn.discordapp.com/embed/avatars/0.png",
		embeds = {embed}
	}
	
	pcall(function()
		HttpService:PostAsync(
			CONFIG.DISCORD_WEBHOOK_URL,
			HttpService:JSONEncode(discordData),
			Enum.HttpContentType.ApplicationJson,
			false
		)
	end)
end

-- Send verification code notification to Discord
local function sendVerificationNotification(player, code, expiresIn)
	local embed = {
		title = "🔗 Discord Link Request",
		description = "A player wants to link their Discord account.",
		color = 5793266,
		fields = {
			{
				name = "Roblox Account",
				value = string.format(
					"**Username:** %s\n**User ID:** %d\n**Profile:** https://www.roblox.com/users/%d/profile",
					player.Name,
					player.UserId,
					player.UserId
				),
				inline = true
			},
			{
				name = "Verification Code",
				value = string.format("```\n%s\n```\nExpires in: %d minutes", code, math.floor(expiresIn / 60)),
				inline = true
			},
			{
				name = "Verification Link",
				value = string.format("%s/verify?code=%s", CONFIG.API_BASE_URL, code),
				inline = false
			}
		},
		timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
	}
	
	local discordData = {
		username = "Account Linker",
		embeds = {embed}
	}
	
	pcall(function()
		HttpService:PostAsync(
			CONFIG.DISCORD_WEBHOOK_URL,
			HttpService:JSONEncode(discordData),
			Enum.HttpContentType.ApplicationJson,
			false
		)
	end)
end

-- ============================================
-- PURCHASE SYSTEM
-- ============================================

-- Calculate total cost with discounts
local function calculateTotal(selections, player)
	local total = 0
	
	-- Ping cost
	total = total + (PRICES.pingTypes[selections.pingType] or 40)
	
	-- Duration cost
	total = total + (PRICES.durations[selections.duration] or 0)
	
	-- Prize amount
	total = total + (selections.prizeAmount or 50)
	
	-- Ad post fee
	if not selections.isStaff then
		total = total + PRICES.adPostFee
	end
	
	-- Store original before discount
	local originalTotal = total
	
	-- Apply discounts
	local discountApplied = false
	local discountType = "None"
	
	local isPlayerPartner, partnerType = isPartner(player)
	if isPlayerPartner then
		total = total * (1 - DISCOUNTS.PARTNER)
		discountApplied = true
		discountType = "Partner (20% off)"
	elseif hasSmallServerDiscount(player) then
		total = total * (1 - DISCOUNTS.SMALL_SERVER)
		discountApplied = true
		discountType = "Small Server (20% off)"
	end
	
	return math.floor(total + 0.5), originalTotal, discountApplied, discountType
end

-- Get product ID for total
local function getProductForTotal(total)
	local productKey = "package_" .. tostring(total)
	return PRODUCT_IDS[productKey]
end

-- Process receipt
local function processReceipt(receiptInfo)
	local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
	
	if not player then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	local purchaseRecordKey = receiptInfo.PlayerId .. "_" .. receiptInfo.PurchaseId
	
	-- Check if already processed
	local success, alreadyProcessed = pcall(function()
		return PURCHASE_DATASTORE:GetAsync(purchaseRecordKey)
	end)
	
	if alreadyProcessed then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	end
	
	-- Get stored purchase details
	local detailsKey = "PendingPurchase_" .. player.UserId
	local purchaseDetails
	
	pcall(function()
		purchaseDetails = PURCHASE_DATASTORE:GetAsync(detailsKey)
	end)
	
	if not purchaseDetails then
		warn("No purchase details found for player " .. player.Name)
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	-- Save purchase record
	local saveSuccess = pcall(function()
		PURCHASE_DATASTORE:SetAsync(purchaseRecordKey, {
			processed = true,
			timestamp = os.time(),
			details = purchaseDetails
		})
	end)
	
	if not saveSuccess then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	-- Get Discord link status
	local linked, linkData = checkDiscordLink(player)
	local discordUsername = linked and linkData.discordUsername or nil
	
	-- Send to Discord
	local playerData = {
		userId = player.UserId,
		username = player.Name,
		displayName = player.DisplayName
	}
	
	local finalPurchaseData = {
		pingType = purchaseDetails.pingType,
		duration = purchaseDetails.duration,
		prizeAmount = purchaseDetails.prizeAmount,
		totalCost = receiptInfo.CurrencySpent,
		originalCost = purchaseDetails.originalCost,
		discordUsername = discordUsername,
		adDetails = purchaseDetails.adDetails
	}
	
	local discountInfo = {
		applied = purchaseDetails.discountApplied,
		type = purchaseDetails.discountType
	}
	
	sendToDiscord(playerData, finalPurchaseData, discountInfo)
	
	-- Clear pending purchase
	pcall(function()
		PURCHASE_DATASTORE:RemoveAsync(detailsKey)
	end)
	
	return Enum.ProductPurchaseDecision.PurchaseGranted
end

MarketplaceService.ProcessReceipt = processReceipt

-- ============================================
-- REMOTE EVENTS & FUNCTIONS
-- ============================================

-- Create RemoteEvent for purchase initiation
local purchaseEvent = Instance.new("RemoteEvent")
purchaseEvent.Name = "InitiatePurchase"
purchaseEvent.Parent = ReplicatedStorage

-- Create RemoteFunction for Discord linking
local generateCodeFunc = Instance.new("RemoteFunction")
generateCodeFunc.Name = "GenerateVerificationCode"
generateCodeFunc.Parent = ReplicatedStorage

-- Create RemoteFunction for checking link status
local checkLinkFunc = Instance.new("RemoteFunction")
checkLinkFunc.Name = "CheckDiscordLink"
checkLinkFunc.Parent = ReplicatedStorage

-- Create RemoteFunction for discount status
local getDiscountFunc = Instance.new("RemoteFunction")
getDiscountFunc.Name = "GetDiscountStatus"
getDiscountFunc.Parent = ReplicatedStorage

-- Create RemoteEvent for notifications
local notifyEvent = Instance.new("RemoteEvent")
notifyEvent.Name = "PurchaseNotification"
notifyEvent.Parent = ReplicatedStorage

-- ============================================
-- EVENT HANDLERS
-- ============================================

-- Handle purchase initiation
purchaseEvent.OnServerEvent:Connect(function(player, purchaseDetails)
	if not purchaseDetails or type(purchaseDetails) ~= "table" then
		warn("Invalid purchase details from " .. player.Name)
		return
	end
	
	-- Calculate totals
	local finalTotal, originalTotal, discountApplied, discountType = calculateTotal(purchaseDetails, player)
	
	-- Store purchase details
	local detailsKey = "PendingPurchase_" .. player.UserId
	pcall(function()
		PURCHASE_DATASTORE:SetAsync(detailsKey, {
			pingType = purchaseDetails.pingType,
			duration = purchaseDetails.duration,
			prizeAmount = purchaseDetails.prizeAmount,
			originalCost = originalTotal,
			discountApplied = discountApplied,
			discountType = discountType,
			adDetails = purchaseDetails.adDetails,
			timestamp = os.time()
		}, 300)
	end)
	
	-- Get product ID
	local productId = getProductForTotal(finalTotal)
	
	if not productId then
		warn("No product found for total: " .. finalTotal .. " Robux")
		notifyEvent:FireClient(player, {
			type = "error",
			message = "Product not available for this total. Contact support."
		})
		return
	end
	
	-- Prompt purchase
	local success, errorMsg = pcall(function()
		MarketplaceService:PromptProductPurchase(player, productId)
	end)
	
	if not success then
		warn("Failed to prompt purchase for " .. player.Name .. ":", errorMsg)
	end
end)

-- Handle verification code generation
generateCodeFunc.OnServerInvoke = function(player)
	local code, expiresAt, expiresIn = generateVerificationCode(player)
	
	if code then
		-- Send notification to Discord
		sendVerificationNotification(player, code, expiresIn)
		
		return {
			success = true,
			code = code,
			expiresAt = expiresAt,
			expiresIn = expiresIn,
			verifyUrl = CONFIG.API_BASE_URL .. "/verify?code=" .. code
		}
	else
		return {
			success = false,
			error = "Failed to generate code. Please try again."
		}
	end
end

-- Handle link status check
checkLinkFunc.OnServerInvoke = function(player)
	local linked, data = checkDiscordLink(player)
	
	return {
		linked = linked,
		discordUsername = data and data.discordUsername or nil,
		discordId = data and data.discordId or nil,
		isPartner = data and data.isPartner or false,
		partnerType = data and data.partnerType or nil
	}
end

-- Handle discount status check
getDiscountFunc.OnServerInvoke = function(player)
	local isPlayerPartner, partnerType = isPartner(player)
	local smallServer = hasSmallServerDiscount(player)
	
	return {
		isPartner = isPlayerPartner,
		partnerType = partnerType,
		hasSmallServerDiscount = smallServer,
		discountPercent = (isPlayerPartner or smallServer) and 20 or 0,
		discountType = isPlayerPartner and "Partner" or (smallServer and "Small Server" or "None")
	}
end

-- ============================================
-- PLAYER JOIN HANDLER
-- ============================================

Players.PlayerAdded:Connect(function(player)
	-- Pre-check Discord link status (async, won't block)
	coroutine.wrap(function()
		wait(2) -- Small delay to let player load
		local linked, data = checkDiscordLink(player)
		if linked then
			print(string.format("Player %s has Discord linked: %s", player.Name, data.discordUsername))
		end
	end)()
end)

-- ============================================
-- ADMIN FUNCTIONS (Server Console)
-- ============================================

_G.SetPartnerStatus = function(userId, isPartner, partnerType)
	print("Use the Discord bot or web API to set partner status")
	print("API: POST /api/partner/manage")
	print("Body: { robloxUserId: '" .. userId .. "', isPartner: " .. tostring(isPartner) .. " }")
end

_G.ClearVerificationCache = function(userId)
	local key = "Link_" .. userId
	pcall(function()
		VERIFICATION_CACHE:RemoveAsync(key)
	end)
	print("Cleared verification cache for user " .. userId)
end

_G.GetLinkStatus = function(userId)
	local url = buildUrl("/api/status/check", { robloxUserId = tostring(userId) })
	local data = httpGet(url)
	if data then
		print(HttpService:JSONEncode(data, true))
	else
		print("Failed to get link status")
	end
end

-- ============================================
-- INITIALIZATION
-- ============================================

print("==============================================")
print("✅ Advertisement Purchase Server Initialized")
print("==============================================")
print("API URL: " .. CONFIG.API_BASE_URL)
print("Partner discount: " .. (DISCOUNTS.PARTNER * 100) .. "%")
print("Small server discount: " .. (DISCOUNTS.SMALL_SERVER * 100) .. "%")
print("")
print("Admin Commands:")
print("  _G.ClearVerificationCache(userId)")
print("  _G.GetLinkStatus(userId)")
print("==============================================")
