'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Link2, Gamepad2, MessageCircle, CheckCircle2, ArrowRight, Shield, Zap, Users } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 mb-6">
            <Badge className="bg-indigo-600 hover:bg-indigo-700 px-4 py-1">
              YourBritishTrainFan&apos;s Giveaway Hub
            </Badge>
          </div>
          
          <h1 className="text-5xl font-bold text-white mb-6">
            Discord & Roblox
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
              Account Linking
            </span>
          </h1>
          
          <p className="text-xl text-slate-400 mb-8">
            Connect your Discord and Roblox accounts to unlock exclusive benefits, 
            automatic partner discounts, and faster advertisement processing.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 h-14"
              onClick={() => window.location.href = '/verify'}
            >
              <Link2 className="mr-2 h-5 w-5" />
              Link Your Accounts
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mt-16">
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Zap className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-white mb-1">Fast</h3>
              <p className="text-slate-400">Instant verification</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Shield className="w-8 h-8 text-green-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-white mb-1">Secure</h3>
              <p className="text-slate-400">Code-based linking</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-indigo-500 mx-auto mb-3" />
              <h3 className="text-2xl font-bold text-white mb-1">Partner</h3>
              <p className="text-slate-400">Auto discounts applied</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <Separator className="bg-slate-700 max-w-4xl mx-auto" />

      {/* How It Works */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          How It Works
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Step 1 */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white">
                  1
                </div>
                <CardTitle className="text-white">In Roblox</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Gamepad2 className="w-12 h-12 text-slate-400" />
              </div>
              <p className="text-slate-400">
                Click &quot;Link Discord&quot; in the advertisement system to generate 
                a unique 6-character verification code.
              </p>
            </CardContent>
          </Card>

          {/* Step 2 */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white">
                  2
                </div>
                <CardTitle className="text-white">On This Site</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <Link2 className="w-12 h-12 text-slate-400" />
              </div>
              <p className="text-slate-400">
                Enter your verification code and Discord username on our 
                verification page to complete the linking process.
              </p>
            </CardContent>
          </Card>

          {/* Step 3 */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white">
                  3
                </div>
                <CardTitle className="text-white">Done!</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <CheckCircle2 className="w-12 h-12 text-green-500" />
              </div>
              <p className="text-slate-400">
                Your accounts are now linked! Enjoy automatic discounts, 
                faster processing, and special Discord roles.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 h-14"
            onClick={() => window.location.href = '/verify'}
          >
            Get Started
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>

      <Separator className="bg-slate-700 max-w-4xl mx-auto" />

      {/* Benefits */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          Benefits of Linking
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-indigo-400" />
                Faster Processing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400">
                Your advertisement purchases are processed faster when your 
                Discord account is linked. Staff can easily identify you and 
                communicate about your orders.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                Partner Discounts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400">
                Partners receive an automatic 20% discount on all advertisement 
                purchases. Small server owners also qualify for special discounts. 
                Linking ensures these are applied automatically.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-400" />
                Account Security
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400">
                Our code-based verification system ensures that only you can 
                link your accounts. Codes expire after 10 minutes and can only 
                be used once.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                Discord Roles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400">
                Linked members receive special roles in our Discord server, 
                giving you access to exclusive channels, early announcements, 
                and priority support.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* API Documentation */}
      <div className="container mx-auto px-4 py-16">
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-white">API Endpoints</CardTitle>
            <CardDescription className="text-slate-400">
              For developers integrating with the linking system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 font-mono text-sm">
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <p className="text-green-400">POST /api/link/generate</p>
                <p className="text-slate-500 mt-1">Generate a verification code from Roblox</p>
              </div>
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <p className="text-blue-400">GET /api/verify/code?code=XXXXXX</p>
                <p className="text-slate-500 mt-1">Check verification code status</p>
              </div>
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <p className="text-green-400">POST /api/verify/code</p>
                <p className="text-slate-500 mt-1">Verify code and link accounts</p>
              </div>
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <p className="text-blue-400">GET /api/status/check?robloxUserId=123</p>
                <p className="text-slate-500 mt-1">Check if account is linked</p>
              </div>
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <p className="text-green-400">POST /api/partner/manage</p>
                <p className="text-slate-500 mt-1">Set partner status for user</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-700 py-8">
        <div className="container mx-auto px-4 text-center text-slate-500 text-sm">
          <p className="mb-2">
            YourBritishTrainFan&apos;s Giveaway Hub - Account Linking System
          </p>
          <p>
            Need help? Join our Discord:{' '}
            <a 
              href="https://discord.gg/wRTJTybKvp" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-indigo-400 hover:text-indigo-300"
            >
              discord.gg/wRTJTybKvp
            </a>
          </p>
        </div>
      </footer>
    </div>
  )
}
