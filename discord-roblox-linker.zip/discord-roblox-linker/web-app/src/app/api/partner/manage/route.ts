import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Manage partner status
// Called from Discord bot or admin panel

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { robloxUserId, isPartner, partnerType, hasSmallServerDiscount, discordRoleId, expiresAt } = body;

    if (!robloxUserId) {
      return NextResponse.json(
        { error: 'Missing robloxUserId' },
        { status: 400 }
      );
    }

    // Upsert partner status
    const partnerStatus = await db.partnerStatus.upsert({
      where: { robloxUserId },
      update: {
        isPartner: isPartner ?? false,
        partnerType: partnerType || null,
        hasSmallServerDiscount: hasSmallServerDiscount ?? false,
        discordRoleId: discordRoleId || null,
        verifiedByDiscord: !!discordRoleId,
        expiresAt: expiresAt ? new Date(expiresAt) : null
      },
      create: {
        robloxUserId,
        isPartner: isPartner ?? false,
        partnerType: partnerType || null,
        hasSmallServerDiscount: hasSmallServerDiscount ?? false,
        discordRoleId: discordRoleId || null,
        verifiedByDiscord: !!discordRoleId,
        expiresAt: expiresAt ? new Date(expiresAt) : null
      }
    });

    // Also update linked account if exists
    await db.linkedAccount.updateMany({
      where: { robloxUserId },
      data: {
        isPartner: isPartner ?? false,
        partnerType: partnerType || null,
        hasSmallServerDiscount: hasSmallServerDiscount ?? false
      }
    });

    // Log the action
    await db.auditLog.create({
      data: {
        action: isPartner ? 'partner_grant' : 'partner_revoke',
        robloxUserId,
        details: JSON.stringify({
          partnerType,
          hasSmallServerDiscount,
          discordRoleId
        }),
        performedBy: 'discord_bot'
      }
    });

    return NextResponse.json({
      success: true,
      partnerStatus
    });

  } catch (error) {
    console.error('Error managing partner status:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Get partner status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const robloxUserId = searchParams.get('robloxUserId');

    if (!robloxUserId) {
      return NextResponse.json(
        { error: 'Missing robloxUserId parameter' },
        { status: 400 }
      );
    }

    const partnerStatus = await db.partnerStatus.findUnique({
      where: { robloxUserId }
    });

    if (!partnerStatus) {
      return NextResponse.json({
        isPartner: false,
        hasSmallServerDiscount: false
      });
    }

    // Check if expired
    if (partnerStatus.expiresAt && partnerStatus.expiresAt < new Date()) {
      return NextResponse.json({
        isPartner: false,
        hasSmallServerDiscount: false,
        expired: true
      });
    }

    return NextResponse.json({
      isPartner: partnerStatus.isPartner,
      partnerType: partnerStatus.partnerType,
      hasSmallServerDiscount: partnerStatus.hasSmallServerDiscount,
      verifiedByDiscord: partnerStatus.verifiedByDiscord,
      expiresAt: partnerStatus.expiresAt?.toISOString()
    });

  } catch (error) {
    console.error('Error getting partner status:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Remove partner status
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const robloxUserId = searchParams.get('robloxUserId');

    if (!robloxUserId) {
      return NextResponse.json(
        { error: 'Missing robloxUserId parameter' },
        { status: 400 }
      );
    }

    await db.partnerStatus.delete({
      where: { robloxUserId }
    });

    // Also update linked account
    await db.linkedAccount.updateMany({
      where: { robloxUserId },
      data: {
        isPartner: false,
        partnerType: null,
        hasSmallServerDiscount: false
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Partner status removed'
    });

  } catch (error) {
    console.error('Error removing partner status:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
