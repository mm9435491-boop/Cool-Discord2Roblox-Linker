import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { randomBytes } from 'crypto';

// Generate a verification code for Roblox player
// Called from Roblox server via HttpService

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate required fields
    const { robloxUserId, robloxUsername, discordUsername } = body;

    if (!robloxUserId || !robloxUsername) {
      return NextResponse.json(
        { error: 'Missing required fields: robloxUserId, robloxUsername' },
        { status: 400 }
      );
    }

    // Check for existing unused code for this user
    const existingCode = await db.verificationCode.findFirst({
      where: {
        robloxUserId: String(robloxUserId),
        isUsed: false,
        expiresAt: { gt: new Date() }
      }
    });

    if (existingCode) {
      // Return existing code if still valid
      return NextResponse.json({
        success: true,
        code: existingCode.code,
        expiresAt: existingCode.expiresAt.toISOString(),
        existing: true
      });
    }

    // Generate a new 6-character verification code
    const generateCode = (): string => {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed confusing chars: I, O, 0, 1
      let code = '';
      const randomValues = randomBytes(6);
      for (let i = 0; i < 6; i++) {
        code += chars[randomValues[i] % chars.length];
      }
      return code;
    };

    let code = generateCode();
    let attempts = 0;

    // Ensure code is unique
    while (attempts < 10) {
      const existing = await db.verificationCode.findUnique({
        where: { code }
      });

      if (!existing) break;

      code = generateCode();
      attempts++;
    }

    if (attempts >= 10) {
      return NextResponse.json(
        { error: 'Failed to generate unique code' },
        { status: 500 }
      );
    }

    // Set expiration to 10 minutes from now
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    // Create the verification code
    const verificationCode = await db.verificationCode.create({
      data: {
        code,
        robloxUserId: String(robloxUserId),
        robloxUsername,
        discordUsername: discordUsername || null,
        expiresAt
      }
    });

    // Log the action
    await db.auditLog.create({
      data: {
        action: 'code_generated',
        robloxUserId: String(robloxUserId),
        details: JSON.stringify({ code, expiresAt: expiresAt.toISOString() }),
        performedBy: 'roblox_server'
      }
    });

    return NextResponse.json({
      success: true,
      code: verificationCode.code,
      expiresAt: verificationCode.expiresAt.toISOString(),
      expiresIn: 600 // seconds
    });

  } catch (error) {
    console.error('Error generating verification code:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Get pending codes (for admin/debug)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const robloxUserId = searchParams.get('robloxUserId');

    if (robloxUserId) {
      // Get all codes for a specific user
      const codes = await db.verificationCode.findMany({
        where: {
          robloxUserId,
          isUsed: false,
          expiresAt: { gt: new Date() }
        },
        orderBy: { createdAt: 'desc' }
      });

      return NextResponse.json({ codes });
    }

    // Get all active codes
    const codes = await db.verificationCode.findMany({
      where: {
        isUsed: false,
        expiresAt: { gt: new Date() }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    return NextResponse.json({ codes });

  } catch (error) {
    console.error('Error fetching codes:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
