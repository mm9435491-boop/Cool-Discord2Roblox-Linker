import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Check if a Roblox account is linked to Discord
// Called from Roblox server to verify linking status

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const robloxUserId = searchParams.get('robloxUserId');
    const discordId = searchParams.get('discordId');

    if (!robloxUserId && !discordId) {
      return NextResponse.json(
        { error: 'Missing robloxUserId or discordId parameter' },
        { status: 400 }
      );
    }

    let linkedAccount;

    if (robloxUserId) {
      linkedAccount = await db.linkedAccount.findUnique({
        where: { robloxUserId }
      });
    } else if (discordId) {
      linkedAccount = await db.linkedAccount.findUnique({
        where: { discordId: discordId! }
      });
    }

    if (!linkedAccount) {
      return NextResponse.json({
        linked: false,
        robloxUserId,
        discordId
      });
    }

    // Also check for partner status
    const partnerStatus = await db.partnerStatus.findUnique({
      where: { robloxUserId: linkedAccount.robloxUserId }
    });

    return NextResponse.json({
      linked: true,
      robloxUserId: linkedAccount.robloxUserId,
      robloxUsername: linkedAccount.robloxUsername,
      discordId: linkedAccount.discordId,
      discordUsername: linkedAccount.discordUsername,
      discordAvatar: linkedAccount.discordAvatar,
      linkedAt: linkedAccount.linkedAt.toISOString(),
      isPartner: linkedAccount.isPartner || partnerStatus?.isPartner || false,
      partnerType: linkedAccount.partnerType || partnerStatus?.partnerType || null,
      hasSmallServerDiscount: linkedAccount.hasSmallServerDiscount || partnerStatus?.hasSmallServerDiscount || false
    });

  } catch (error) {
    console.error('Error checking status:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Unlink accounts
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { robloxUserId, discordId } = body;

    if (!robloxUserId && !discordId) {
      return NextResponse.json(
        { error: 'Missing robloxUserId or discordId' },
        { status: 400 }
      );
    }

    let linkedAccount;

    if (robloxUserId) {
      linkedAccount = await db.linkedAccount.findUnique({
        where: { robloxUserId }
      });
    } else {
      linkedAccount = await db.linkedAccount.findUnique({
        where: { discordId: discordId! }
      });
    }

    if (!linkedAccount) {
      return NextResponse.json(
        { error: 'No linked account found' },
        { status: 404 }
      );
    }

    // Delete the linked account
    await db.linkedAccount.delete({
      where: { id: linkedAccount.id }
    });

    // Log the action
    await db.auditLog.create({
      data: {
        action: 'unlink',
        robloxUserId: linkedAccount.robloxUserId,
        discordId: linkedAccount.discordId,
        details: JSON.stringify({
          robloxUsername: linkedAccount.robloxUsername,
          discordUsername: linkedAccount.discordUsername
        }),
        performedBy: 'api_request'
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Accounts unlinked successfully'
    });

  } catch (error) {
    console.error('Error unlinking accounts:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
