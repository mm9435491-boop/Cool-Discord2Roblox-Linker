import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Verify a code and link Discord account
// Called from web interface when Discord user enters their code

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate required fields
    const { code, discordId, discordUsername, discordAvatar } = body;

    if (!code || !discordId || !discordUsername) {
      return NextResponse.json(
        { error: 'Missing required fields: code, discordId, discordUsername' },
        { status: 400 }
      );
    }

    // Normalize the code (uppercase, trim)
    const normalizedCode = code.toUpperCase().trim();

    // Find the verification code
    const verificationCode = await db.verificationCode.findUnique({
      where: { code: normalizedCode }
    });

    if (!verificationCode) {
      return NextResponse.json(
        { error: 'Invalid verification code', code: 'INVALID_CODE' },
        { status: 404 }
      );
    }

    // Check if code is already used
    if (verificationCode.isUsed) {
      return NextResponse.json(
        { error: 'This code has already been used', code: 'CODE_USED' },
        { status: 400 }
      );
    }

    // Check if code is expired
    if (verificationCode.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'This code has expired. Please generate a new one in Roblox.', code: 'CODE_EXPIRED' },
        { status: 400 }
      );
    }

    // Check if Discord account is already linked
    const existingLink = await db.linkedAccount.findUnique({
      where: { discordId }
    });

    if (existingLink) {
      return NextResponse.json(
        { error: 'This Discord account is already linked to a Roblox account', code: 'ALREADY_LINKED' },
        { status: 400 }
      );
    }

    // Check if Roblox account is already linked
    const existingRobloxLink = await db.linkedAccount.findUnique({
      where: { robloxUserId: verificationCode.robloxUserId }
    });

    if (existingRobloxLink) {
      return NextResponse.json(
        { error: 'This Roblox account is already linked to a Discord account', code: 'ROBLOX_ALREADY_LINKED' },
        { status: 400 }
      );
    }

    // Mark code as used
    await db.verificationCode.update({
      where: { id: verificationCode.id },
      data: {
        isUsed: true,
        usedAt: new Date(),
        usedByDiscordId: discordId
      }
    });

    // Create the linked account
    const linkedAccount = await db.linkedAccount.create({
      data: {
        robloxUserId: verificationCode.robloxUserId,
        robloxUsername: verificationCode.robloxUsername,
        discordId,
        discordUsername,
        discordAvatar: discordAvatar || null,
        verificationId: verificationCode.id
      }
    });

    // Log the action
    await db.auditLog.create({
      data: {
        action: 'link',
        robloxUserId: verificationCode.robloxUserId,
        discordId,
        details: JSON.stringify({
          robloxUsername: verificationCode.robloxUsername,
          discordUsername,
          code: normalizedCode
        }),
        performedBy: discordId
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Accounts linked successfully!',
      link: {
        robloxUsername: linkedAccount.robloxUsername,
        robloxUserId: linkedAccount.robloxUserId,
        discordUsername: linkedAccount.discordUsername,
        linkedAt: linkedAccount.linkedAt.toISOString()
      }
    });

  } catch (error) {
    console.error('Error verifying code:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Get verification code info (to show user what they're linking)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');

    if (!code) {
      return NextResponse.json(
        { error: 'Missing code parameter' },
        { status: 400 }
      );
    }

    const normalizedCode = code.toUpperCase().trim();

    const verificationCode = await db.verificationCode.findUnique({
      where: { code: normalizedCode }
    });

    if (!verificationCode) {
      return NextResponse.json(
        { error: 'Invalid verification code' },
        { status: 404 }
      );
    }

    // Return info without sensitive data
    return NextResponse.json({
      code: verificationCode.code,
      robloxUsername: verificationCode.robloxUsername,
      discordUsername: verificationCode.discordUsername,
      isUsed: verificationCode.isUsed,
      expiresAt: verificationCode.expiresAt.toISOString(),
      isExpired: verificationCode.expiresAt < new Date()
    });

  } catch (error) {
    console.error('Error fetching code info:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
