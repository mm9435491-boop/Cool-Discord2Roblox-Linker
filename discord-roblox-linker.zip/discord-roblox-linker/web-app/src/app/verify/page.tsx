'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import { Loader2, CheckCircle2, XCircle, AlertTriangle, Link2, User, Clock } from 'lucide-react'

interface CodeInfo {
  code: string
  robloxUsername: string
  discordUsername: string | null
  isUsed: boolean
  expiresAt: string
  isExpired: boolean
}

interface LinkResult {
  success: boolean
  message: string
  link?: {
    robloxUsername: string
    robloxUserId: string
    discordUsername: string
    linkedAt: string
  }
}

export default function VerifyPage() {
  const [code, setCode] = useState('')
  const [discordUsername, setDiscordUsername] = useState('')
  const [discordId, setDiscordId] = useState('')
  const [loading, setLoading] = useState(false)
  const [checkingCode, setCheckingCode] = useState(false)
  const [codeInfo, setCodeInfo] = useState<CodeInfo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<LinkResult | null>(null)
  const [countdown, setCountdown] = useState<number | null>(null)

  // Format countdown timer
  const formatCountdown = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }, [])

  // Check code when user types 6 characters
  useEffect(() => {
    const checkCode = async () => {
      if (code.length === 6) {
        setCheckingCode(true)
        setError(null)
        setCodeInfo(null)

        try {
          const response = await fetch(`/api/verify/code?code=${code}`)
          const data = await response.json()

          if (response.ok) {
            setCodeInfo(data)
          } else {
            setError(data.error || 'Invalid code')
          }
        } catch {
          setError('Failed to verify code')
        } finally {
          setCheckingCode(false)
        }
      } else {
        setCodeInfo(null)
        setError(null)
      }
    }

    const timeoutId = setTimeout(checkCode, 300)
    return () => clearTimeout(timeoutId)
  }, [code])

  // Countdown timer for code expiration
  useEffect(() => {
    if (codeInfo && !codeInfo.isExpired && !codeInfo.isUsed) {
      const interval = setInterval(() => {
        const expiresAt = new Date(codeInfo.expiresAt).getTime()
        const now = Date.now()
        const remaining = Math.max(0, Math.floor((expiresAt - now) / 1000))
        setCountdown(remaining)

        if (remaining === 0) {
          setCodeInfo(prev => prev ? { ...prev, isExpired: true } : null)
        }
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [codeInfo])

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch('/api/verify/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: code.toUpperCase(),
          discordId: discordId || `discord_${Date.now()}`, // In production, get from OAuth
          discordUsername,
          discordAvatar: null
        })
      })

      const data = await response.json()

      if (response.ok) {
        setResult(data)
        setCodeInfo(null)
        setCode('')
      } else {
        setError(data.error || 'Failed to link accounts')
      }
    } catch {
      setError('Failed to connect to server')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-600 mb-4">
            <Link2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Link Your Accounts</h1>
          <p className="text-slate-400">
            Connect your Discord and Roblox accounts for exclusive benefits
          </p>
        </div>

        {/* Main Card */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <User className="w-5 h-5" />
              Account Verification
            </CardTitle>
            <CardDescription className="text-slate-400">
              Enter the verification code displayed in Roblox
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Success Result */}
            {result && (
              <Alert className="mb-6 bg-green-900/30 border-green-600 text-green-200">
                <CheckCircle2 className="h-4 w-4" />
                <AlertTitle>Success!</AlertTitle>
                <AlertDescription>
                  <p className="mb-2">{result.message}</p>
                  {result.link && (
                    <div className="mt-3 p-3 bg-green-900/50 rounded-lg text-sm">
                      <p><strong>Roblox:</strong> {result.link.robloxUsername}</p>
                      <p><strong>Discord:</strong> {result.link.discordUsername}</p>
                      <p><strong>Linked:</strong> {new Date(result.link.linkedAt).toLocaleString()}</p>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {/* Error Display */}
            {error && (
              <Alert className="mb-6 bg-red-900/30 border-red-600 text-red-200">
                <XCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Code Info Display */}
            {codeInfo && !result && (
              <div className="mb-6 p-4 rounded-lg bg-slate-700/50 border border-slate-600">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-slate-400 text-sm">Verifying as:</span>
                  {codeInfo.isUsed ? (
                    <Badge variant="destructive">Already Used</Badge>
                  ) : codeInfo.isExpired ? (
                    <Badge variant="destructive">Expired</Badge>
                  ) : countdown !== null && countdown < 60 ? (
                    <Badge variant="warning" className="bg-yellow-600">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatCountdown(countdown)}
                    </Badge>
                  ) : (
                    <Badge className="bg-green-600">Valid</Badge>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">{codeInfo.robloxUsername}</p>
                    <p className="text-sm text-slate-400">Roblox Account</p>
                  </div>
                </div>
              </div>
            )}

            {/* Main Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Verification Code Input */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">
                  Verification Code
                </label>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Enter 6-character code"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 6))}
                    className="bg-slate-900/50 border-slate-600 text-white text-center text-2xl tracking-[0.5em] font-mono h-14 uppercase"
                    maxLength={6}
                    disabled={loading || !!result}
                  />
                  {checkingCode && (
                    <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 animate-spin text-indigo-400" />
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Get this code from the game by clicking &quot;Link Discord&quot;
                </p>
              </div>

              {/* Discord Username Input */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">
                  Discord Username
                </label>
                <Input
                  type="text"
                  placeholder="username or username#1234"
                  value={discordUsername}
                  onChange={(e) => setDiscordUsername(e.target.value)}
                  className="bg-slate-900/50 border-slate-600 text-white"
                  disabled={loading || !!result}
                />
              </div>

              {/* Discord ID (Optional - for testing) */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">
                  Discord ID <span className="text-slate-500">(optional)</span>
                </label>
                <Input
                  type="text"
                  placeholder="Your Discord user ID (for testing)"
                  value={discordId}
                  onChange={(e) => setDiscordId(e.target.value)}
                  className="bg-slate-900/50 border-slate-600 text-white"
                  disabled={loading || !!result}
                />
              </div>

              <Separator className="bg-slate-700" />

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white h-12"
                disabled={loading || !codeInfo || codeInfo.isUsed || codeInfo.isExpired || !discordUsername || !!result}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Linking Accounts...
                  </>
                ) : (
                  <>
                    <Link2 className="mr-2 h-4 w-4" />
                    Link Accounts
                  </>
                )}
              </Button>
            </form>

            {/* Reset Button after success */}
            {result && (
              <Button
                variant="outline"
                className="w-full mt-4 border-slate-600 text-slate-300"
                onClick={() => {
                  setResult(null)
                  setCode('')
                  setCodeInfo(null)
                  setDiscordUsername('')
                  setDiscordId('')
                }}
              >
                Link Another Account
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <div className="mt-6 text-center text-slate-500 text-sm">
          <p className="mb-2">
            <AlertTriangle className="inline w-4 h-4 mr-1" />
            Codes expire after 10 minutes
          </p>
          <p>
            Need help? Contact staff on our Discord server
          </p>
        </div>

        {/* Features List */}
        <Card className="mt-6 bg-slate-800/30 border-slate-700">
          <CardContent className="p-4">
            <h3 className="font-semibold text-white mb-3">Benefits of Linking:</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Faster advertisement processing
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Automatic partner discounts (if applicable)
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Priority support in Discord
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                Special role in Discord server
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
